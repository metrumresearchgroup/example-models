# This file is part of RStan
# Copyright (C) 2012, 2013, 2014, 2015 Trustees of Columbia University
#
# RStan is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 3
# of the License, or (at your option) any later version.
#
# RStan is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

git_head <- function() "57643021a05d101485c55f7b331ea59d91a3cd75"
git_head <- function() "04cfa06a318f7947c8610d2a857c9cb64c16b8fe"
git_head <- function() "04cfa06a318f7947c8610d2a857c9cb64c16b8fe"
git_head <- function() "edb702c04ad7a29cabc0f192679700574fee6ab9"
git_head <- function() "bf61c9a85c6425f0553aad93ee9052d03c448dd2"
git_head <- function() "2ecf3f718c301f60df6a2f81a27dc5c473c2f43c"
git_head <- function() "05c3d0058b6a42c7caf6fe6e04f17bb7a4a0258b"
git_head <- function() "85f7a56811da8e3c73bf92d6978111eea45d0c6c"
git_head <- function() "5fa1e80eb8173ff81c98a00c96d39dd942950ce5"
